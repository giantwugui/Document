package com.springboot.chapter3.pojo.definition;

public interface Animal {
	public void use();
}
