package com.springboot.chapter3.pojo.definition;

public interface Person {
	
	public void service();
	
	public void setAnimal(Animal animal);
	
}
