package com.springboot.chapter4.service;

public interface HelloService {
	
	public void sayHello(String name);
}
