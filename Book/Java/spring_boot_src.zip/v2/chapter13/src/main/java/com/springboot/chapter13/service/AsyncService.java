package com.springboot.chapter13.service;

public interface AsyncService {
	// 模拟报表生成的异步方法
	public void generateReport();
}
