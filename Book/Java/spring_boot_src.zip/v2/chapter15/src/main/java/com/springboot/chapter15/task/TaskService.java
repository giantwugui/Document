package com.springboot.chapter15.task;
public interface TaskService {
    /***
     * 购买定时任务
     */
    public void purchaseTask();
}