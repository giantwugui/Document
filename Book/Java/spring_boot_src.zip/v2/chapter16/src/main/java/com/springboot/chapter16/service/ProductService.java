package com.springboot.chapter16.service;

import com.springboot.chapter16.pojo.Product;

public interface ProductService {
	
	Product getProduct(Long id);
}
